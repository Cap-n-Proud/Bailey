FIR filter Arduino Library
==========================

FIR filter to Arduino. The code is from this thread: http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1279123369/3
Credits to Rene Knuvers for the initial code and to AlphaBeta for making it libraryesque.

I just did the work of converting it to a working Arduino library. Tested in Arduino IDE 1.0.1.

The library is used in this project: http://sebastiannilsson.com/k/projekt/selfbalancing-robot/

--------------------------------------------------------------------------------
To use the library:

1. Download the zip and uncompress the downloaded file. 

2. Copy the folder to the Arduino sketchbook\libraries folder.

3. Rename it to FIR